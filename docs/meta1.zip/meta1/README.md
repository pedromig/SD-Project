# SD-Project: eVoting

## About The Project
Project for the Distributed Systems subject of the Informatics engineering course @University of Coimbra

## Installing and Running
This project is distributed by packages. To generate compiled .class files or the jar packages
needed in order to run the project there are 3 options.

### Option 1 - Use the jar files provided
In the folder "jar" there are some jars that were generated to make it easier the testing 
of this project. To run the use 

* java -jar file.jar

NOTES: These programs may need config files

### Option 2 - Using and IDE (IntelliJ IDEA)
For this project we used IntelliJ IDEA IDE to develop our code. IntelliJ has great build tools
that allows us to build compile and run our project with ease. Should you wish to use this IDE 
please import directly the "project" folder that was provided.

This folder has all the source code needed in order to run the project and has the IDE
generated project configuration files included.

### Option 3 - Compiling with javac and generating the jars by hand
The project is devided by modules. Each module has the implementation of the features asked
in the statement of this project. The packages might have dependencies of files contained in
other packages (keep that in mind while compiling by hand) 

Here is a list a packages and their dependecies
 - multicast  (depends on files from rmi.interfaces.* and utils.*)
 - rmi (dependds on files from utils.*)
 - console (dependes on files from utils.*)
 - utils 

* To compile with javac use: javac *.class

## Configuration and database files

- In the case of the rmiserver if a path must be specified as a command line argument
  in order for the program to know where the database files will be placed. If the program cannot 
  find the path for such folder the program will not start throwing an error.
  
- The server and terminal programs of this project require some configuration.properties files.
  The paths to these files are suplied to the program via command line arguments.
  If the server or terminal cannot find the files in the specified path the programs will throw
  and error message and startup using default configurations
  Here are some examples of such files and the key value pairs that they must have.

### server.properties (these are also defaults)

server.department.name=DEI
multicast.discovery.group=224.3.2.1
multicast.discovery.port=6789
multicast.voting.group=224.3.2.2
multicast.voting.port=4321
rmi.server.ip=localhost
rmi.server.port=7000

### terminal.properties (these are also defaults)

terminal.id=VT-1
multicast.discovery.group=224.3.2.1
multicast.discovery.port=6789


# Authors
  - Miguel Rabuge
  - Pedro Rodrigues
