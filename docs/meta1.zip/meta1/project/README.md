# SD-Project
![APM](https://img.shields.io/apm/l/vim-mode)
![BUILD](https://img.shields.io/badge/build-passing-green)

## About The Project
Project for the Distributed Systems subject of the Informatics engineering course @University of Coimbra

# Collaborators
  - Miguel Rabuge (https://github.com/MikeLrUC)
